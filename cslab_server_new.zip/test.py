import platform

system_name = platform.system()
print(system_name)
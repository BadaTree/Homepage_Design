class VetorCalibration:
    pass
class WifimapRssiSequential:
    pass